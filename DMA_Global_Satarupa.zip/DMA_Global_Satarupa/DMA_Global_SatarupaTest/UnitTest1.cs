﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using DMA_Global_Satarupa;

namespace DMA_Global_SatarupaTest
{
 
    [TestClass]
    public class UnitTest1
    {
 
        [TestMethod]
        public void Test_Case1()
        {
            DMA_Global_Satarupa.DMA_Global_Satarupa bm = new DMA_Global_Satarupa.DMA_Global_Satarupa();
            double res = bm.BalanceAmount(100,"USD", 300,0);
            Assert.AreEqual(res, 700);
        }
        [TestMethod]
        public void Test_Case2()
        {
            
            int numTrans = 3;
            double res=0;
            for (int i = 1; i <= numTrans; i++)
            {
                if (i == 1)
                {
                    DMA_Global_Satarupa.DMA_Global_Satarupa bm = new DMA_Global_Satarupa.DMA_Global_Satarupa();
                    res = bm.BalanceAmount(35000, "MXN", 0,5000);
                }
                if (i == 2)
                {
                    DMA_Global_Satarupa.DMA_Global_Satarupa bm = new DMA_Global_Satarupa.DMA_Global_Satarupa();
                    res = bm.BalanceAmount(res, "USD", 0,12500);
                }
                if (i == 3)
                {
                    DMA_Global_Satarupa.DMA_Global_Satarupa bm = new DMA_Global_Satarupa.DMA_Global_Satarupa();
                    res = bm.BalanceAmount(res, "CAD", 300, 0);
                }
                
            }
            Assert.AreEqual(res, 9800);
        }
        [TestMethod]
        public void Test_Case3()
        {
            int Account_Num_Count = 2;
            for (int j = 1; j <= Account_Num_Count; j++)
            {
                if (j == 1)
                {
                    int numTrans = 3;
                    double res = 0;
                    for (int i = 1; i <= numTrans; i++)
                    {
                        if (i == 1)
                        {
                            DMA_Global_Satarupa.DMA_Global_Satarupa bm = new DMA_Global_Satarupa.DMA_Global_Satarupa();
                            res = bm.BalanceAmount(15000, "CAD", 0, 5000);
                        }
                        if (i == 2)
                        {
                            DMA_Global_Satarupa.DMA_Global_Satarupa bm = new DMA_Global_Satarupa.DMA_Global_Satarupa();
                            res = bm.BalanceAmount(res, "CAD", 7300, 0);
                        }
                       

                    }
                    Assert.AreEqual(res, 17300);
                }

                if (j == 2)
                {
                    int numTrans = 3;
                    double res = 0;
                    for (int i = 1; i <= numTrans; i++)
                    {
                        if (i == 1)
                        {
                            DMA_Global_Satarupa.DMA_Global_Satarupa bm = new DMA_Global_Satarupa.DMA_Global_Satarupa();
                            res = bm.BalanceAmount(7425, "CAD", 0, 7300);
                        }
                        if (i == 2)
                        {
                            DMA_Global_Satarupa.DMA_Global_Satarupa bm = new DMA_Global_Satarupa.DMA_Global_Satarupa();
                            res = bm.BalanceAmount(res, "MXN", 13726, 0);
                        }
                       

                    }
                    Assert.AreEqual(res, 1497.60);
                }
            }
        }
        [TestMethod]
        public void Test_Case4()
        {
            int Account_Num_Count = 2;
            for (int j = 1; j <= Account_Num_Count; j++)
            {
                if (j == 1)
                {
                    int numTrans = 3;
                    double res = 0;
                    for (int i = 1; i <= numTrans; i++)
                    {
                        if (i == 1)
                        {
                            DMA_Global_Satarupa.DMA_Global_Satarupa bm = new DMA_Global_Satarupa.DMA_Global_Satarupa();
                            res = bm.BalanceAmount(150, "USD", 0, 70);
                        }
                        if (i == 2)
                        {
                            DMA_Global_Satarupa.DMA_Global_Satarupa bm = new DMA_Global_Satarupa.DMA_Global_Satarupa();
                            res = bm.BalanceAmount(res, "CAD", 23.75, 0);
                        }


                    }
                    Assert.AreEqual(res, 33.75);
                }

                if (j == 2)
                {
                    int numTrans = 3;
                    double res = 0;
                    for (int i = 1; i <= numTrans; i++)
                    {
                        if (i == 1)
                        {
                            DMA_Global_Satarupa.DMA_Global_Satarupa bm = new DMA_Global_Satarupa.DMA_Global_Satarupa();
                            res = bm.BalanceAmount(65000, "USD", 23789,0);
                        }
                        if (i == 2)
                        {
                            DMA_Global_Satarupa.DMA_Global_Satarupa bm = new DMA_Global_Satarupa.DMA_Global_Satarupa();
                            res = bm.BalanceAmount(res, "CAD", 0, 23.75);
                        }


                    }
                    Assert.AreEqual(res, 112554.25);
                }
            }
        }

        [TestMethod]
        public void Test_Case5()
        {
            double res = 0;
            DMA_Global_Satarupa.DMA_Global_Satarupa bm = new DMA_Global_Satarupa.DMA_Global_Satarupa();
            res = bm.Match_Account("219", "1010",7425,"USD", 0, 100);
                     
            Assert.AreEqual(res, 7425);
         }
            
        
    }
}
