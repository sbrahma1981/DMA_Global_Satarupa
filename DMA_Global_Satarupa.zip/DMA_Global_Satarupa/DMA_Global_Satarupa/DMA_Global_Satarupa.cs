﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DMA_Global_Satarupa
{
    public class DMA_Global_Satarupa
    {

        //Functions for first 4 test cases
        public double BalanceAmount(double Initial_Amount, string currency, double Deposit_Amount,double Withdraw_Amount)
        {
         
            if (currency == "USD")
            {

                Deposit_Amount = Deposit_Amount / .5;
            }
            if (currency == "MXN")
            {

                Deposit_Amount = Deposit_Amount / 10;
            }
           
            if (currency == "USD")
            {

                Withdraw_Amount = Withdraw_Amount / .5;
            }
            if (currency == "MXN")
            {

                Withdraw_Amount = Withdraw_Amount / 10;
            }
          
            return Initial_Amount + Deposit_Amount- Withdraw_Amount;
           

        }

        //Functions for 5th test case
        public double Match_Account(string Cust_ID, string Acct_Num, double Initial_Amount, string currency, double Deposit_Amount, double Withdraw_Amount)
        {
            if (currency == "USD")
            {

                Deposit_Amount = Deposit_Amount / .5;
            }
            if (currency == "MXN")
            {

                Deposit_Amount = Deposit_Amount / 10;
            }

            if (currency == "USD")
            {

                Withdraw_Amount = Withdraw_Amount / .5;
            }
            if (currency == "MXN")
            {

                Withdraw_Amount = Withdraw_Amount / 10;
            }
            

            if (Cust_ID == "002")
            {
                return Initial_Amount + Deposit_Amount - Withdraw_Amount;
            }
            else
            {
                return Initial_Amount;
            }


        }

        static void Main(string[] args)
        {
        }
    }
}
